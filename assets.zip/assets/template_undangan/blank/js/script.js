'use strict';

console.log('Template BLANK adalah template contoh');